import java.util.*;

public class GestorAulas {
    private List<EspacioBase> espacios = new ArrayList<>();

   /**
     * Agrega una Espacio a la lista de Espacios del gestor
     */
   public void agregar(EspacioBase espacio) {
        //TODO Implementar
    }

    /**
     * Elimina de la lista el EspacioBase  cuyo nombre coincide
     * con el nombre pasado como argumento.
     */
     public void eliminar(String nombre) {
        //TODO Implementar
    }

    /**
     * Actualiza la capacidad y ubicación del EspacioBase cuyo
     * nombre coincide con el nombre pasado como argumento.
     */
     public void modificar(String nombre, int nuevaCapacidad, TipoSector nuevoSector) {
      //TODO Implementar
    }

    /**
     * Devuelve el EspacioBase cuyo nombre coincide con el nombre
     * pasado como argumento
     */
    public EspacioBase buscar(String nombre) {
         //TODO Implementar
        return null;
    }

    /**
     * Devuelve una lista con todos los EspacioBase del
     * gestor 
     */
    public List<EspacioBase> getTodos() {
        //TODO Implementar
    }
}