public interface Ocultable {
    void ocultar(boolean visible);
}