public class Aula extends EspacioBase  {
    public Aula(String nombre, int capacidad, TipoSector sector) {
        super(nombre, capacidad, sector);
    }
}