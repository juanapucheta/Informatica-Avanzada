import java.util.*;
import java.time.LocalDateTime;

public import java.util.*;
import java.time.LocalDateTime;

class GestorReservas {
    private GestorAulas gestorAulas;
    protected Map<EspacioBase, List<Reserva>> reservas;

    public GestorReservas(GestorAulas gestorAulas ) {
        this.gestorAulas = gestorAulas;
        this.reservas = new HashMap<EspacioBase, List<Reserva>>():
        for (EspacioBase e : gestorAulas.getTodos()) {
            reservas.put(e, new ArrayList<>());
        }
    }
    
    public List<Reserva> getReservasPorEspacio (String nombreEspacio){
        EspacioBase espacio = gestorAulas.buscar(nombreEspacio);
        List<Reserva> listaReservas=null;
        if (espacio !=null && reservas.containsKey(espacio)) {
           listaReservas = reservas.get(espacio);
        }
        return listaReservas;
    }


    /**
     * Reserva una espacio para un usuario, a la hora y con la duración indicada
     *  
     * Si la espacio no existe en el gestor -> Lanza Exception ()
     * Revisa todas las reservas asociadas al espacio, y si existe alguna
     * que se superpone -> Lanza Exception )=
     * 
     * Si el espacio existe, y no tienen ninguna reserva superpuesta
     * se genera una nueva Reserva y se agrega al mapa de reservas
     * y retorna true
     * 
     * @throw Exception si la sala no existe, o si tiene una reserva en el 
     * horario requerido
     * @return true si se pudo generar la reserva.
     * 
     */
    public boolean reservar(String nombreEspacio, Usuario usuario, LocalDateTime inicio, int duracion) throws Exception {
         //TODO implementar método.
        return true;
    }

    /**
     * Libera el espacio de la reserva agendada a la hora epecificada.
     * 
     * Obitene el Espacio por su nombre del gestor de Auls, si no existe o no tiene
     * reservas asociadas, no hace nada.
     * 
     * Recorre la lista de reservas del espacio, busca si hay alguno que inicie
     * a la hora especificada y la remueve.
     * 
     */
     public void liberar(String nombreEspacio, LocalDateTime inicio) {
       //TODO implementar. 
    }

    /**
     * devuevle una lista de todos los espacios  DISPONIBLES con una capacidad
     * mínima y en una ubicación.
     * 
     * Recorre todos los espacios existentes, y de cada espacio recorre la lista de 
     * reservas y determina si están o no disponibles a la hora indicada 
     * por el tiempo indicado. Si está disponible, agrega el espacio a la lista.
     * 
     * @return la lista con todas las salas disponbiles.
     */
    public List<EspacioBase> disponibles(LocalDateTime inicio, int duracion) {
       List<EspacioBase> disponibles = new ArrayList<EspacioBase>();
       List<EspacioBase> todas = gestorAulas.getTodos();
       //TODO implementar método
       return null;
     
    }
}