public abstract class EspacioBase {
    protected String nombre;
    protected int capacidad;
    protected TipoSector sector;

    /**
     * Constructor con parámetros
     * Inicializa las variables de instancia
     */
    public EspacioBase(String nombre, int capacidad, TipoSector sector) {
          //TODO Implementar método
    }

    public String getNombre() {
        //TODO Implementar
    }
    public int getCapacidad() {
        //TODO Implementar
    }
    public TipoSector getSector()  {
        //TODO Implementar
    }
    
    /**
     * Setea la capacidad de la sala
     * solo si la capacidad es mayor a 0
     */
    public void setCapacidad(int capacidad)  {
        //TODO Implementar
    }
    public void setSector(TipoSector sector) { 
           //TODO Implementar
    }

    @Override
    /**
     * Retorna una representación del Espacio Base como String con el formato
     * 
     * "<nombre> (<apacidad> personas, <sector>)"
     * 
     *  Ejemplo: 
     *      lab1 (6 personas, Piso dos)
     */
    public String toString() { 
           //TODO Implementar
    }
}