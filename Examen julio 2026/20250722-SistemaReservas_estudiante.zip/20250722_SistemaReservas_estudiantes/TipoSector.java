public enum TipoSector {
    PRIMER_PISO, SEGUNDO_PISO, LABORATORIO, AUDITORIO;

    @Override
    public String toString() {
        return name().replace("_", " ").toLowerCase();
    }
}